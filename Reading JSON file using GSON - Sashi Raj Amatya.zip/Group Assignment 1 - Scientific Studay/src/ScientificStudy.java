
public class ScientificStudy {

}
